# CodeDeploy_SampleApp_Linux

This code is based on AWS' s3://aws-codedeploy-eu-west-1/samples/latest/SampleApp_Linux.zip
